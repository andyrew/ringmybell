# Create a twitter app here https://apps.twitter.com/ 
# Then and copy the key info below

consumer_key	="(your key goes here)"
consumer_secret	="(your secret key goes here)"
access_token	="(your key goes here)"
access_token_secret	="(your secret key goes here)"

